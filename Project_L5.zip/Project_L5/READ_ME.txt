ALEX LAEL ALEM DIOBA MICKOMBA 
Writing the algorithms
SAYED AHMAD SHAH AFTABI
Code running and double check